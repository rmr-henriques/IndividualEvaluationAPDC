package pt.unl.fct.di.apdc.individualevaluation.util;

public class LogoutData {

	public String tokenID;
	
	public LogoutData() {}
	
	public LogoutData(String tokenID) {
		this.tokenID = tokenID;
	}
}