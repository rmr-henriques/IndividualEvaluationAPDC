package pt.unl.fct.di.apdc.individualevaluation.util;

public class NewPasswordData {

	public String password;
	public String confirmation;
	public String tokenID;
	
	public NewPasswordData() {}
	
	public NewPasswordData(String tokenID, String password, String confirmation) {
		this.tokenID = tokenID;
		this.password = password;
		this.confirmation = confirmation;
	}
	
}
