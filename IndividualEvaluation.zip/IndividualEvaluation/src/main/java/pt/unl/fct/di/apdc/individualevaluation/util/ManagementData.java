package pt.unl.fct.di.apdc.individualevaluation.util;

public class ManagementData {
	public String predatorTokenID;
	public String preyUsername;
	
	public ManagementData() {}
	
	public ManagementData(String predatorTokenID, String preyUsername) {
		this.predatorTokenID = predatorTokenID;
		this.preyUsername = preyUsername;
	}
}
